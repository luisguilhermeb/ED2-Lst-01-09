//
//  Laboratório 7 - Implementação da Tabela Hash
//  -> Use M como 31, 79, 151.
//  -> Entrada: 100, 1000, 10000 strings.
//  
//  GILDO FERREIRA DIAS FILHO       - 201905451 - TURMA 'A'
//  LUIS GUILHERME BARBOSA CUSTODIO - 201905500 - TURMA 'B'
//
//   Obs.: Faça o anexo do arquivo "100 Nomes.txt" antes de compilar
//

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define M 31    // Use M como 31 -> 100; 79 -> 1000; 151 -> 10000.

// dado do tipo pessoa
typedef struct {
    char nome[50];
} Pessoa;

// tipo nó usado para criar a lista encadeada
typedef struct no {
    Pessoa pessoa;
    struct no *proximo;
} No;

// tipo lista com um ponteiro para o primeiro nó
typedef struct {
    No *inicio;
    int tam;
} Lista;

// tipo lista p/ os ponteiros da tabela
Lista *tabela[M];


// imprime o nome dentro de um endereço da tabela hash
void imprimirPessoa(Pessoa p) {
    printf("\tNome: %s\n", p.nome);
}

// cria uma lista vazia e retorna seu endereço na memória
Lista* criarLista() {
    Lista *l = malloc(sizeof(Lista));
    l->inicio = NULL;
    l->tam = 0;
    return l;
}

// insere o nome no inicio de cada lista dentro da tabela hash
void inserirInicio(Pessoa p, Lista *lista) {
    No *no = malloc(sizeof(No));
    no->pessoa = p;
    no->proximo = lista->inicio;
    lista->inicio = no;
    lista->tam++;
}

void imprimirLista(No *inicio) {
    while(inicio != NULL) {
        imprimirPessoa(inicio->pessoa);
        inicio = inicio->proximo;
    }
}

// inicializa a tabela com uma lista vazia em cada posição do vetor
void inicializar(){
    int i;
    for(i = 0; i < M; i++)
        tabela[i] = criarLista();
}

// função chave dos elementos para tabela hash
int funcaoHash(int mat){
    return mat % M;
}

// cria uma pessoa e a insere na tabela
void inserTabela(){
  clock_t Ticks[2];
  Ticks[0] = clock(); // inicia a contagem do tempo de execução
    Pessoa p;
            FILE *pont_arq;
            char c = ' ';
            pont_arq = fopen("100 Nomes.txt","r"); // abre o arquivo .txt contendo os nomes
            if (pont_arq == NULL)
            {
                printf("Erro ao tentar abrir o arquivo!");
                exit(1);
            }
            printf("\nLendo os dados do arquivo .txt e criando tabela hash...\n");
                //faz a leitura do caracter no arquivo apontado por pont_arq
                fgets(p.nome, 50, pont_arq);
                int cont=0;
            do
                {  
                    fgets(p.nome, 50, pont_arq);
                    Pessoa pes = p;
                                int indice = funcaoHash((rand() % 100)); // funcaoHash resto %M através de numeros aleatorios (maior dispersão comparado ao %M por n° de letras de cada string etc)
                                inserirInicio(pes, tabela[indice]); // insere a string no inicio da lista
                                cont++;
                }while (cont < 100); // contador para quantidade de elementos do arquivo
            
                fclose(pont_arq); // fecha o arquivo .txt
  Ticks[1] = clock(); // finaliza a contagem do tempo de execução
  double Tempo = (Ticks[1] - Ticks[0]) * 1000.0 / CLOCKS_PER_SEC;
  printf("Tempo gasto: %g ms.\n", Tempo);
  getchar();
}

// imprime a tabela hash
void imprimirTabela(){
    int i, aux=0;
    printf("\n---------------------TABELA-------------------------\n");
    for(i = 0; i < M; i++){
        printf("%d Lista tamanho: %d\n", i, tabela[i]->tam);
        imprimirLista(tabela[i]->inicio);
        if(tabela[i]->tam > 1){
        aux+= tabela[i]->tam-1;
        }
    }
    printf("\nO numero total de colisoes foi de: %d \n", aux); // exibe o numero total de colisoes -1 do proprio elemento
    printf("---------------------FIM DA TABELA-----------------------\n");
}

int main() {
    int operacao;
    Pessoa *p;

    inicializar();
    do {
        printf("\n0 - Sair\n1 - Inserir 100 nomes na tabela\n2 - Imprimir tabela\n");
        scanf("%d", &operacao);
        switch(operacao) {
        case 0:
            printf("Saindo...\n");
            break;
        case 1:
            inserTabela();
            break;
        case 2:
            imprimirTabela();
            break;
        default:
            printf("Opcao invalida!\n");
        }
    } while(operacao != 0);

    return 0;
}